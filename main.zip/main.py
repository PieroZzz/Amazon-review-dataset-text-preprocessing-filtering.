from utils import *
from DecisionTree import DecisionTree
from Bayes import NaiveBayes
import warnings
warnings.filterwarnings("ignore")
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score,roc_auc_score,f1_score,recall_score,precision_score


def test_decisiontree():
    train_features_1, train_labels_1, test_features_1, test_labels_1, train_features_2, train_labels_2, test_features_2, test_labels_2= load_decisiontree_dataset()
    # 用A - AM列（人口统计和情绪）、FU - GY列（个性）、AN - FT列（情境元素）预测GZ - KR列（行为元素）、KS列（正 / 负结果）的概率
    print('用A - AM列（人口统计和情绪）、FU - GY列（个性）、AN - FT列（情境元素）预测GZ - KR列（行为元素）、KS列（正 / 负结果）的概率:')
    for i in range(0, train_labels_1.shape[1]):
        model = DecisionTree()
        model.fit(train_features_1, train_labels_1[:, i])
        results = model.predict(test_features_1)
        print('{:d}.DecisionTree acc: {:.2f}%'.format(i + 1, get_acc(results, test_labels_1[:, i]) * 100))
    # 使用A - AM栏（人口统计和情绪）、FU - GY栏（个性）、GZ - KR栏（行为要素） ) 来预测列的概率AN - FT
    print('使用A - AM栏（人口统计和情绪）、FU - GY栏（个性）、GZ - KR栏（行为要素） ) 来预测列的概率AN - FT:')
    for i in range(0, train_labels_2.shape[1]):
        model = DecisionTree()
        model.fit(train_features_2, train_labels_2[:, i])
        results = model.predict(test_features_2)
        print('{:d}.DecisionTree acc: {:.2f}%'.format(i + 1, get_acc(results, test_labels_2[:, i]) * 100))

def test_bayes():
    train_features_1, train_labels_1, test_features_1, test_labels_1, train_features_2, train_labels_2, test_features_2, test_labels_2 = load_decisiontree_dataset()
    # 用A - AM列（人口统计和情绪）、FU - GY列（个性）、AN - FT列（情境元素）预测GZ - KR列（行为元素）、KS列（正 / 负结果）的概率
    print('用A - AM列（人口统计和情绪）、FU - GY列（个性）、AN - FT列（情境元素）预测GZ - KR列（行为元素）、KS列（正 / 负结果）的概率:')
    for i in range(0, train_labels_1.shape[1]):
        Nayes = NaiveBayes()
        train_label = np.array(train_labels_1[:, i]).astype(int).reshape(-1, 1)
        test_label = np.array(test_labels_1[:, i]).astype(int).reshape(-1, 1)
        Nayes.fit(train_features_1, train_label)  # 在训练集上计算先验概率和条件概率
        results = Nayes.predict(test_features_1)
        print('{:d}.Bayes acc: {:.2f}%'.format(i + 1, get_acc(results, test_label) * 100))
    # 使用A - AM栏（人口统计和情绪）、FU - GY栏（个性）、GZ - KR栏（行为要素） ) 来预测列的概率AN - FT
    print('使用A - AM栏（人口统计和情绪）、FU - GY栏（个性）、GZ - KR栏（行为要素） ) 来预测列的概率AN - FT:')
    for i in range(0, train_labels_2.shape[1]):
        Nayes = NaiveBayes()
        train_label = np.array(train_labels_2[:, i]).astype(int).reshape(-1, 1)
        test_label = np.array(test_labels_2[:, i]).astype(int).reshape(-1, 1)
        Nayes.fit(train_features_2, train_label)  # 在训练集上计算先验概率和条件概率
        results = Nayes.predict(test_features_2)
        print('{:d}.Bayes acc: {:.2f}%'.format(i + 1, get_acc(results, test_label) * 100))


if __name__=='__main__':
    test_decisiontree()
    test_bayes()
