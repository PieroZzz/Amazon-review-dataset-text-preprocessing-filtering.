import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split  #数据分区
def get_acc(y, pred):
    return np.sum(y == pred) / len(y)


def load_decisiontree_dataset():
    data = pd.read_excel('data.xlsx')
    dataset = np.array(data)
    # 下划线为1表示用A - AM列（人口统计和情绪）、FU - GY列（个性）、AN - FT列（情境元素）预测GZ - KR列（行为元素）、KS列（正 / 负结果）的概率
    features_1 = dataset[:, 0:176]
    labels_1 = dataset[:, 207:305]
    # 下划线为2表示使用A - AM栏（人口统计和情绪）、FU - GY栏（个性）、GZ - KR栏（行为要素） ) 来预测列的概率AN - FT
    f1 = dataset[:, 0:39]
    f2 = dataset[:, 176:305]
    features_2 = np.concatenate((f1, f2), axis=1)
    labels_2 = dataset[:, 39:176]
    # 随机划分训练集和测试集
    train_features_1, test_features_1, train_labels_1, test_labels_1 = train_test_split(features_1, labels_1,
                                                                                        test_size=0.3, random_state=0)
    train_features_2, test_features_2, train_labels_2, test_labels_2 = train_test_split(features_2, labels_2,
                                                                                        test_size=0.3, random_state=0)

    return train_features_1, train_labels_1, test_features_1, test_labels_1, train_features_2, train_labels_2, test_features_2, test_labels_2

if __name__=='__main__':
    load_decisiontree_dataset()